Airline website

to install all of the dependencies, first run: 

npm i 

To launch the server while develeping run:

npm run devStart
